# encoding: utf-8
# module geomag
# from C:\Users\qinli\AppData\Local\Programs\Python\Python36\lib\site-packages\geomag\emm.cp36-win_amd64.pyd
# by generator 1.145
# no doc

# imports
import geomag.emm as emm # C:\Users\qinli\AppData\Local\Programs\Python\Python36\lib\site-packages\geomag\emm.cp36-win_amd64.pyd

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__path__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

